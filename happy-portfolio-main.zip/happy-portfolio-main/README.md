# happy-portfolio
&lt;h2>About Me&lt;/h2> &lt;p>Hello! I'm Mohammed Akama Adoyo, a web developer based in Kenya. I specialize in creating beautiful, user-friendly websites that help businesses grow online. I'm passionate about clean code, responsive design, and building websites that drive results.&lt;/p>
